/*
 * Broadcom Proprietary and Confidential. Copyright 2016 Broadcom
 * All Rights Reserved.
 *
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
 * the contents of this file may not be disclosed to third parties, copied
 * or duplicated in any form, in whole or in part, without the prior
 * written permission of Broadcom Corporation.
 */

/** @file
 *
 * A rudimentary AWS IOT publisher application which demonstrates how to connect to
 * AWS IOT cloud (MQTT Broker) and publish MQTT messages for a given topic.
 *
 * This application publishes "LIGHT ON" or "LIGHT OFF" message for each button press
 * to topic "WICED_BULB" with QOS1. Button used is WICED_BUTTON1 on the WICED board.
 * If we press the button first time it publishes "LIGHT OFF" and if we press next the same button
 * it will publish "LIGHT ON".
 *
 * To run the app, work through the following steps.
 *  1. Modify Wi-Fi configuration settings CLIENT_AP_SSID and CLIENT_AP_PASSPHRASE in wifi_config_dct.h to match your router settings.
 *  2. Update the AWS MQTT broker address (MQTT_BROKER_ADDRESS) if needed.
 *  3. Make sure AWS Root Certifcate 'resources/apps/aws_iot/rootca.cer' is up to date while building the app.
 *  4. Copy client certificate and private key for the given AWS IOT user in resources/apps/aws_iot folder.
 *     Ensure that valid client certificates and private keys are provided for the AWS IOT user in resources/apps/aws_iot folder.
 *  5. Build and run this application.
 *  6. Run another application which subscribes to the same topic.
 *  7. Press button WICED_BUTTON1 to publish the messages "LIGHT ON" or LIGHT OFF" alternatively and check if
 *     it reaches subscriber app running on the other WICED board (which can be anywhere but connected to internet)
 *
 */

#include "wiced.h"
#include "mqtt_api.h"
#include "resources.h"









wiced_mqtt_object_t   mqtt_object_publish;
wiced_mqtt_object_t   mqtt_object_subscribe;

uint32_t              size_out = 0;
int                   connection_retries = 0;
int                   retries = 0;
int                   retries1 = 0;
int                   retries2 = 0;
int                   retries3 = 0;
char*                 msg[100]; //for sending mqtt data
char*                 msgS[100];//for recieving mqtt data
wiced_ip_address_t ipv4address;
char ip_str[25];
char name_str[25];
char* devicename = "";
char* alert = "true";

uint32_t i=0;



wiced_thread_t MQTTPublishHandle;
wiced_semaphore_t MQTTPublishSemaphore;//
wiced_thread_t MQTTSubscribeHandle;
wiced_semaphore_t MQTTSubscribeSemaphore;//


//For AWS, your MQTT Broker address can be found by logging in to the AWS IOT COnsole, go to
//registry, your thing, interact, and copy the https rest api endpoint

#define MQTT_BROKER_ADDRESS                 "a2vkjpd80xdrym.iot.us-east-1.amazonaws.com" // if you create a new thing change this and the certificates

//TO PUBLISH OR SUBSCRIBE TO A SHADOW, THE TOPICS NEED TO BE SET LIKE BELOW. FOR THIS DEMO WE WILL USE SIMPLE TOPIC NAMES
//char* WICED_TOPIC       =                   "$aws/things/ww101_02/shadow/update"; //this needs to be unique for each application
//char* WICED_TOPIC_SUBSCRIBE = "$aws/things/ww101_02/shadow/update";//this needs to be unique for each application
#define WICED_TOPIC_1                        "TOPIC_1"
#define WICED_TOPIC_2                        "TOPIC_2"
char* WICED_TOPIC                  =      WICED_TOPIC_1; //this is the topic that will be published to
char* WICED_TOPIC_SUBSCRIBE        =        WICED_TOPIC_2; //this is the topic that will be subscribed to

char* CLIENT_ID          =                 "";//this needs to be unique for each node
#define MQTT_REQUEST_TIMEOUT                (5000)
#define MQTT_REQUEST_TIMEOUT_1                (5000)
#define MQTT_DELAY_IN_MILLISECONDS          (1000)
#define MQTT_MAX_RESOURCE_SIZE              (0x7fffffff)
#define MQTT_PUBLISH_RETRY_COUNT            (3)
#define RETRIES (1)
#define DISABLE_DMA (WICED_TRUE)
#define NUM_MESSAGES (1)
#define MQTT_SUBSCRIBE_RETRY_COUNT          (3)


//flags used to determine if uart entry is required and if so is it complete for setting network id and name
uint32_t SSIDComplete = 0;
uint32_t PasswordComplete = 0;
uint32_t NameComplete = 0;
uint32_t ClientComplete = 0;
uint32_t initialSSID=0;

uint32_t subscribe_count = 0;//counters to be used to increment the topics
uint32_t publish_count = 0;

/******************************************************
 *               Variable Definitions
 ******************************************************/
static wiced_ip_address_t                   broker_address;
static wiced_mqtt_event_type_t              expected_event;
static wiced_semaphore_t                    publish_msg_semaphore;
static wiced_semaphore_t                    subscribe_msg_semaphore;
static wiced_semaphore_t                    unsubscribe_msg_semaphore;


static wiced_mqtt_security_t                security;
static uint8_t                              pub_in_progress = 0;
static uint16_t                             counter =0;
/******************************************************
 *                      Macros
 ******************************************************/


//the wait for functions are blocking functions that wait for the defined semaphore to be set within the defined timeout value.
//if the function deosn't get the semaphore before the timeout, it will return WICED ERROR.
//It may also return WCIED ERROR if it is the wrong event. otherwise it will return WICED SUCCESS
/*
 * A blocking call to an expected event. used for publish events
 */
static wiced_result_t mqtt_wait_for_publish( wiced_mqtt_event_type_t event, uint32_t timeout )
{
    if ( wiced_rtos_get_semaphore( &publish_msg_semaphore, timeout ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
        WPRINT_APP_INFO(("wait for error \n\r"));
    }
    else
    {
        if ( event != expected_event )
        {
            WPRINT_APP_INFO(("wait for event error \n\r"));
            return WICED_ERROR;
        }
    }
    return WICED_SUCCESS;
}

/*
 * A blocking call to an expected event. used for subscribe events
 */
static wiced_result_t mqtt_wait_for_subscribe( wiced_mqtt_event_type_t event, uint32_t timeout )
{
    if ( wiced_rtos_get_semaphore( &subscribe_msg_semaphore, timeout ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    else
    {
        if ( event != expected_event )
        {
            return WICED_ERROR;
        }
    }
    return WICED_SUCCESS;
}

static wiced_result_t mqtt_wait_for_unsubscribe( wiced_mqtt_event_type_t event, uint32_t timeout )
{
    if ( wiced_rtos_get_semaphore( &unsubscribe_msg_semaphore, timeout ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    else
    {
        if ( event != expected_event )
        {
            return WICED_ERROR;
        }
    }
    return WICED_SUCCESS;
}



//this function opens a connection to the defined MQTT Broker with required type, address and passes the required callback function for events
/*
 * Open a connection and wait for MQTT_REQUEST_TIMEOUT period to receive a connection open OK event
 */
static wiced_result_t mqtt_conn_open( wiced_mqtt_object_t mqtt_obj, wiced_ip_address_t *address, wiced_interface_t interface, wiced_mqtt_callback_t callback, wiced_mqtt_security_t *security )
{
    wiced_mqtt_pkt_connect_t conninfo;
    wiced_result_t ret = WICED_SUCCESS;

    memset( &conninfo, 0, sizeof( conninfo ) );
    conninfo.port_number = 0;
    conninfo.mqtt_version = WICED_MQTT_PROTOCOL_VER4;
    conninfo.clean_session = 1;
    conninfo.client_id = (uint8_t*) CLIENT_ID;
    conninfo.keep_alive = 5;
    conninfo.password = NULL;
    conninfo.username = NULL;
    conninfo.peer_cn = (uint8_t*) "*.iot.us-east-1.amazonaws.com"; //this is the last part of your broker address. this needs changing if you change your thing address or type
    ret = wiced_mqtt_connect( mqtt_obj, address, interface, callback, security, &conninfo );
    if ( ret != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    if ( mqtt_wait_for_publish( WICED_MQTT_EVENT_TYPE_CONNECT_REQ_STATUS, MQTT_REQUEST_TIMEOUT ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    return WICED_SUCCESS;
}



/*
 * Publish (send) message to WICED_TOPIC and wait for 5 seconds to receive a PUBCOMP
 */
static wiced_result_t mqtt_app_publish( wiced_mqtt_object_t mqtt_obj, uint8_t qos, uint8_t *topic, uint8_t *data, uint32_t data_len )
{
    wiced_mqtt_msgid_t pktid;

    pktid = wiced_mqtt_publish( mqtt_obj, topic, data, data_len, qos );

    if ( pktid == 0 )
    {
        return WICED_ERROR;

    }

    if ( mqtt_wait_for_publish( WICED_MQTT_EVENT_TYPE_PUBLISHED, MQTT_REQUEST_TIMEOUT_1 ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    return WICED_SUCCESS;
}

/*
 * Close a connection and wait for 5 seconds to receive a connection close OK event
 */
static wiced_result_t mqtt_conn_close( wiced_mqtt_object_t mqtt_obj )
{
    if ( wiced_mqtt_disconnect( mqtt_obj ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    if ( mqtt_wait_for_publish( WICED_MQTT_EVENT_TYPE_DISCONNECTED, MQTT_REQUEST_TIMEOUT ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    return WICED_SUCCESS;
}


/*
 * Call back function to handle connection events this is passed in the connection open function
 */
static wiced_result_t mqtt_connection_event_cb( wiced_mqtt_object_t mqtt_object_publish, wiced_mqtt_event_info_t *event )
{
    switch ( event->type )
    {
    case WICED_MQTT_EVENT_TYPE_CONNECT_REQ_STATUS:
    case WICED_MQTT_EVENT_TYPE_DISCONNECTED:
    case WICED_MQTT_EVENT_TYPE_PUBLISHED:

    {
        expected_event = event->type;
        wiced_rtos_set_semaphore( &publish_msg_semaphore ); //for either of the 3 events above, set the publish msg semaphore
    }
    break;

    case WICED_MQTT_EVENT_TYPE_SUBCRIBED:
    {
        expected_event = event->type;
        wiced_rtos_set_semaphore( &subscribe_msg_semaphore ); //if there is a subscribe event set the subscribe event semaphore
    }
    break;

    case WICED_MQTT_EVENT_TYPE_UNSUBSCRIBED:
    {
        expected_event = event->type;
        wiced_rtos_set_semaphore( &unsubscribe_msg_semaphore ); //if there is an unsubscribe event set the unsubscribe semaphore
    }
    break;

    case WICED_MQTT_EVENT_TYPE_PUBLISH_MSG_RECEIVED:    //if the local device receives a message, copy the data and print it out over uart
    {

        wiced_mqtt_topic_msg_t msg = event->data.pub_recvd;
        memcpy( msgS, msg.data, msg.data_len );
        WPRINT_APP_INFO(("msg recieved %s \n\r", msgS));

    }
    break;
    default:

        break;
    }
    return WICED_SUCCESS;
}

/*
 * Subscribe to WICED_TOPIC and wait for 5 seconds to receive an Acknowledge.
 */
static wiced_result_t mqtt_app_subscribe( wiced_mqtt_object_t mqtt_obj, char *topic, uint8_t qos )
{
    wiced_mqtt_msgid_t pktid;
    pktid = wiced_mqtt_subscribe( mqtt_obj, topic, qos );
    if ( pktid == 0 )
    {
        return WICED_ERROR;
    }
    if ( mqtt_wait_for_subscribe( WICED_MQTT_EVENT_TYPE_SUBCRIBED, 5000 ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    return WICED_SUCCESS;
}

//unsubscribe fromt the defined wiced topic, and wait 5 seconds for an indication you've been successful
static wiced_result_t mqtt_app_unsubscribe( wiced_mqtt_object_t mqtt_obj, char *topic)
{
    wiced_mqtt_msgid_t pktid;
    pktid = wiced_mqtt_unsubscribe( mqtt_obj, topic );
    if ( pktid == 0 )
    {
        return WICED_ERROR;
    }
    if ( mqtt_wait_for_unsubscribe( WICED_MQTT_EVENT_TYPE_UNSUBSCRIBED, 5000 ) != WICED_SUCCESS )
    {
        return WICED_ERROR;
    }
    return WICED_SUCCESS;
}


//this is a separate thread that has been created to handle what to do when we want to publish a message to the cloud
//allowing the main thread or other threads to run simultaneously
void MQTTPublishThread(wiced_thread_arg_t arg)
{
    wiced_result_t        ret;

    while ( 1 ) //wait in a while 1 loop to stay in the tread
    {
        wiced_rtos_get_semaphore( &MQTTPublishSemaphore, WICED_NEVER_TIMEOUT );//wait for semaphore to be set

        if ( pub_in_progress == 1 ) //if the flag has been set in the button press callback
        {
            WPRINT_APP_INFO(("[MQTT] Publishing..."));

            sprintf(msg,"{\"state\": { \"reported\":{\"DeviceName\":\"%s\", \"IPAddress\":\"%s\", \"button press count\":%d}}}", name_str, ip_str, counter );
            //the sprintf fucntion formats the messgae that we want to publish, combing data in to a single string to be sent

            retries = 0; // reset retries to 0 before going into the loop
            do
            {
                ret = mqtt_app_publish( mqtt_object_publish, WICED_MQTT_QOS_DELIVER_AT_MOST_ONCE, (uint8_t*) WICED_TOPIC, (uint8_t*) msg, strlen( msg ) );
                retries++ ;
            } while ( ( ret != WICED_SUCCESS ) && ( retries < MQTT_PUBLISH_RETRY_COUNT ) );
            //inside the do while loop we will try to publish the message  for at least how many times as defined by the retry count value

            if ( ret != WICED_SUCCESS ) //if the publish fails
            {
                WPRINT_APP_INFO((" Failed\n"));
                mqtt_conn_close( mqtt_object_publish );//close the connection and then try to reopen it to see if that fixes the issue for the next attempt
                MQTT_Open_Function();

            }
            else
            {
                WPRINT_APP_INFO((" Success\n"));//if it succeeds print debug code to show it was successful
            }

            pub_in_progress = 0;//reset flag

        }//end of if pub
    }//end of while1
}//end of thread


void mqtt_subscribe_function(void) //function to subscribe to a mqtt topic
{
    wiced_result_t        ret;

    WPRINT_APP_INFO(("[MQTT] Subscribing..."));
    do
    {
        ret = mqtt_app_subscribe( mqtt_object_publish, WICED_TOPIC_SUBSCRIBE, WICED_MQTT_QOS_DELIVER_AT_MOST_ONCE );//subscribe to the defined topic
        retries++ ;
    } while ( ( ret != WICED_SUCCESS ) && ( retries < MQTT_SUBSCRIBE_RETRY_COUNT ) );
    //in the do while loop we attempt to subscribe to the defined topic for as many attempts as defined in by the retry count value

    if ( ret != WICED_SUCCESS )//if it fails to subscribe
    {
        WPRINT_APP_INFO((" Failed to subscribe\n"));
        mqtt_conn_close( mqtt_object_publish );//close the connection and then try to reopen it to see if that fixes the issue for the next attempt
        MQTT_Open_Function();
        return;
    }
    else
    {
        WPRINT_APP_INFO(("Success subscribed to topic... %s\n", WICED_TOPIC_SUBSCRIBE));//if it succeeds print debug code to show it was successful
    }



}

void mqtt_unsubscribe_function(void) //function to unsubscribe from a mqtt topic
{
    wiced_result_t        ret;

    WPRINT_APP_INFO(("[MQTT] Unsubscribing..."));
    do
    {
        ret = mqtt_app_unsubscribe( mqtt_object_publish, WICED_TOPIC_SUBSCRIBE);//unsubscribe to the defined topic
        retries1++ ;
    } while ( ( ret != WICED_SUCCESS ) && ( retries1 < MQTT_SUBSCRIBE_RETRY_COUNT ) );

    //in the do while loop we attempt to unsubscribe to the defined topic for as many attempts as defined in by the retry count value

    if ( ret != WICED_SUCCESS ) //if we fail to unsubscribe
    {
        WPRINT_APP_INFO((" Failed to unsubscribe\n"));
        mqtt_conn_close( mqtt_object_publish );//close the connection and then try to reopen it to see if that fixes the issue for the next attempt
        MQTT_Open_Function();
        return;
    }
    else
    {
        WPRINT_APP_INFO(("Success unsubscribed from topic... %s\n", WICED_TOPIC_SUBSCRIBE));
    }

}


//this function reads the DCT and prints the SSID, security settings and password. this is debug feature, not recommended for production applications
void print_network_info( )
{
    platform_dct_wifi_config_t*  wifi_config;

    // Get a copy of the WIFT config from the DCT into RAM
    wiced_dct_read_lock((void**) &wifi_config, WICED_FALSE, DCT_WIFI_CONFIG_SECTION, 0, sizeof(platform_dct_wifi_config_t));

    // Print info
    WPRINT_APP_INFO(("SSID = %s\n\r",wifi_config->stored_ap_list[0].details.SSID.value));
    WPRINT_APP_INFO(("Security = %dS\n\r",wifi_config->stored_ap_list[0].details.security));
    WPRINT_APP_INFO(("Passphrase = %s\n\r",wifi_config->stored_ap_list[0].security_key));

    // Free RAM buffer
    wiced_dct_read_unlock(wifi_config, WICED_FALSE);
}


//this custom function checks to see if flags have been set in the main application to see whether the device has connected to the DCT SSID.
//if it hasn't it will allow you to enter a SSID and password other a terminal application
//for the aws demo purpose it will also allow you to set a custom device name which will be mapped to the client ID as well
//the device and client id need to be individual for every node so this is an easy way to enable multiple devices in a test environment with their own unique id
void Set_Network_ID(void)
{

    static char ssid[25] = ""; //variables to store inputted ssid, pass phrase and device name
    static char password[25] = "";
    static char name[25] = "";


    char c;
    uint32_t i=0;
    uint32_t expected_data_size = 1;
    platform_dct_wifi_config_t*  wifi_config;

#define SSID_STR          "\r\nEnter SSID. Press Esc to restart or Carriage Return when complete\r\n> "
#define PASS_STR          "\r\nEnter Password. Press Esc to restart or Carriage Return when complete\r\n> "
#define NAME_STR          "\r\nEnter Device Name. e.g. ww101_x Press Esc to restart or Carriage Return when complete\r\n> "
#define CLIENT_STR          "\r\nEnter Client number. Type Client_xx where xx is a different number per node Press Esc to restart or Carriage Return when complete\r\n> "

#define SECURITY   WICED_SECURITY_WPA2_MIXED_PSK //CHANGE THIS DEFINE IF DIFFERENT NETWORK TYPE is required
#define cr  "\r\n"
    wiced_result_t res;

    wiced_uart_transmit_bytes( STDIO_UART, SSID_STR, sizeof( SSID_STR ) - 1 ); //send ssid string
    while(SSIDComplete!=1)
    {

        /* Wait for user input. If received, echo it back to the terminal */
        if( wiced_uart_receive_bytes( STDIO_UART, &c, &expected_data_size, WICED_NEVER_TIMEOUT ) == WICED_SUCCESS )
        {

            if(c==0xD) //if CR pressed
            {
                wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) ); //send return
                wiced_uart_transmit_bytes( STDIO_UART, ssid, strlen(ssid) ); //print the enterred ssid
                wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
                SSIDComplete=1;

                i=0;
            }
            else if(c==0x1B) //if escape pressed reset string pointer
            {

                i=0;
            }
            else //if valid character add it to string and echo to display
            {
                ssid[i] = c;
                wiced_uart_transmit_bytes( STDIO_UART, &c, 1 );
                expected_data_size = 1;
                i++;
            }

        }

    }//end of while ssidcomplete

    wiced_uart_transmit_bytes( STDIO_UART, PASS_STR, sizeof( PASS_STR ) - 1 ); //send password string
    while(PasswordComplete!=1)
    {

        /* Wait for user input. If received, echo it back to the terminal */
        if( wiced_uart_receive_bytes( STDIO_UART, &c, &expected_data_size, WICED_NEVER_TIMEOUT ) == WICED_SUCCESS )
        {

            if(c==0xD)
            {
                wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
                wiced_uart_transmit_bytes( STDIO_UART, password, strlen(password) );
                wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
                PasswordComplete=1;

                i=0;
            }
            else if(c==0x1B)
            {
                i=0;
            }
            else
            {
                password[i] = c;
                wiced_uart_transmit_bytes( STDIO_UART, &c, 1 );
                expected_data_size = 1;
                i++;
            }

        }

    }//end of while password complete


    wiced_uart_transmit_bytes( STDIO_UART, NAME_STR, sizeof( NAME_STR ) - 1 ); //send name string
    while(NameComplete!=1)
    {

        /* Wait for user input. If received, echo it back to the terminal */
        if( wiced_uart_receive_bytes( STDIO_UART, &c, &expected_data_size, WICED_NEVER_TIMEOUT ) == WICED_SUCCESS )
        {

            if(c==0xD)
            {
                wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
                wiced_uart_transmit_bytes( STDIO_UART, name, strlen(name) );
                wiced_uart_transmit_bytes( STDIO_UART, cr, sizeof(cr) );
                NameComplete=1;

                i=0;
            }
            else if(c==0x1B)
            {
                i=0;
            }
            else
            {
                name[i] = c;
                wiced_uart_transmit_bytes( STDIO_UART, &c, 1 );
                expected_data_size = 1;
                i++;
            }

        }

    }//end of device name complete



    devicename = name; //set the device name and client to the same inputted string for simplicity
    CLIENT_ID = name;

    WPRINT_APP_INFO(("devicename = %s\n\r",devicename));//print them out over uart
    WPRINT_APP_INFO(("client id = %s\n\r",CLIENT_ID));


    if(initialSSID==0) //if not already connected at start up, bring the network down and update the DCT with enterred data
    {
        wiced_network_down(WICED_STA_INTERFACE); //take network down

        wiced_dct_read_lock((void**) &wifi_config, WICED_TRUE, DCT_WIFI_CONFIG_SECTION, 0, sizeof(platform_dct_wifi_config_t));
        strncpy((char *)wifi_config->stored_ap_list[0].details.SSID.value , ssid, strlen(ssid));
        strncpy((char *)wifi_config->stored_ap_list[0].security_key , password, strlen(password));
        wifi_config->stored_ap_list[0].details.security = WICED_SECURITY_WPA2_MIXED_PSK;
        wifi_config->stored_ap_list[0].security_key_length = strlen(password);
        wifi_config->stored_ap_list[0].details.SSID.length = strlen(ssid);



        // Write updated parameters to the DCT
        res = wiced_dct_write((const void *) wifi_config, DCT_WIFI_CONFIG_SECTION, 0, sizeof(platform_dct_wifi_config_t));
        if(res == WICED_SUCCESS)
        {
            WPRINT_APP_INFO(("DCT write SUCCEEDED\n\r"));
        }
        else
        {
            WPRINT_APP_INFO(("DCT write FAILED\n\r"));
        }

        wiced_dct_read_unlock(wifi_config, WICED_TRUE);
        print_network_info();


        /* Bring up the network interface */
        res = wiced_network_up( WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL );
        if ( res != WICED_SUCCESS )
        {
            WPRINT_APP_INFO( ( "\nNot able to join the requested AP\n\n" ) );
            return;
        }

    }//end if initial ssid
}


//this function opens a connection to the  defined broker address
void MQTT_Open_Function(void)
{
    wiced_result_t        ret;

    WPRINT_APP_INFO(("[MQTT] Opening connection publish ..."));
    do
    {
        ret = mqtt_conn_open( mqtt_object_publish, &broker_address, WICED_STA_INTERFACE, mqtt_connection_event_cb, &security );
        connection_retries++ ;
    } while ( ( ret != WICED_SUCCESS ) && ( connection_retries < WICED_MQTT_CONNECTION_NUMBER_OF_RETRIES ) );
    //inside the do while loop, the function attempts to connect as many times as defined by the number of retries


    if ( ret != WICED_SUCCESS ) //if it fails to connect
    {
        WPRINT_APP_INFO(("Failed\n"));

    }
    else
    {
    WPRINT_APP_INFO(("Success publish connection\n"));//if it does connect, print debug data
    }


}

//this is the defined callback for when we get a button press interrupt on the defined GPIO
static void publish_callback( void* arg )
{

    pub_in_progress = 1;//SET FLAG TO SAY WE WANT TO PUBLISH
    wiced_rtos_set_semaphore( &MQTTPublishSemaphore );//SET THE SEMAPHORE FOR THE PUBLISH THREAD TO GET
    counter++; //INCREMENT BUTTON PRESS COUNTER

}

/******************************************************
 *              this is the main application start function
 ******************************************************/
void application_start( void )
{

    wiced_init( ); //INITIALISE THE DEVICE

    wiced_result_t res;
    res = wiced_network_up(WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL); //BRING THE WIFI NETWORK INTERFACE UP

    if(res==0) //if we connect to the network pre stored in the dct, set the flags to skip entry request over uart
    {
        SSIDComplete=1;
        PasswordComplete = 1;
        initialSSID = 1;
    }
    Set_Network_ID(); //set ssid if required, password if required, and device name by uart

    //security setup

    /* Get AWS root certificate, client certificate and private key respectively */
    //the privkey and client key may need to be unique for each device. if changed they need to be changed in the mk file as well
    resource_get_readonly_buffer( &resources_apps_DIR_aws_iot_DIR_customAWScerts_DIR_rootca_cer, 0, MQTT_MAX_RESOURCE_SIZE, &size_out, (const void **) &security.ca_cert );
    security.ca_cert_len = size_out;

    resource_get_readonly_buffer( &resources_apps_DIR_aws_iot_DIR_customAWScerts_DIR_client_cer, 0, MQTT_MAX_RESOURCE_SIZE, &size_out, (const void **) &security.cert );
    if(size_out < 64)
    {
        WPRINT_APP_INFO( ( "\nNot a valid Certificate! Please replace the dummy certificate file 'resources/app/aws_iot/client.cer' with the one got from AWS\n\n" ) );
        return;
    }
    security.cert_len = size_out;

    resource_get_readonly_buffer( &resources_apps_DIR_aws_iot_DIR_customAWScerts_DIR_privkey_cer, 0, MQTT_MAX_RESOURCE_SIZE, &size_out, (const void **) &security.key );
    if(size_out < 64)
    {
        WPRINT_APP_INFO( ( "\nNot a valid Private Key! Please replace the dummy private key file 'resources/app/aws_iot/privkey.cer' with the one got from AWS\n\n" ) );
        return;
    }
    security.key_len = size_out;

    //end of security setup


    //mqtt setup
    /* Allocate memory for MQTT object*/
    mqtt_object_publish = (wiced_mqtt_object_t) malloc( WICED_MQTT_OBJECT_MEMORY_SIZE_REQUIREMENT );
    if ( mqtt_object_publish == NULL )
    {
        WPRINT_APP_ERROR("Dont have memory to allocate for mqtt object publish...\n");
        return;
    }



    WPRINT_APP_INFO( ( "Resolving IP address of MQTT broker...\n" ) );
    res = wiced_hostname_lookup( MQTT_BROKER_ADDRESS, &broker_address, 10000,WICED_STA_INTERFACE);
    WPRINT_APP_INFO(("Resolved Broker IP: %u.%u.%u.%u\n\n", (uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 24),
            (uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 16),
            (uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 8),
            (uint8_t)(GET_IPV4_ADDRESS(broker_address) >> 0)));
    if ( res == WICED_ERROR || broker_address.ip.v4 == 0 )
    {
        WPRINT_APP_INFO(("Error in resolving DNS\n"));
        return;
    }


    //INITIALISE ALL THE SEMAPHORES
    wiced_rtos_init_semaphore(&MQTTPublishSemaphore);
    wiced_rtos_init_semaphore(&publish_msg_semaphore);
    wiced_rtos_init_semaphore(&MQTTSubscribeSemaphore);
    wiced_rtos_init_semaphore(&subscribe_msg_semaphore);
    wiced_rtos_init_semaphore(&unsubscribe_msg_semaphore);

    //CREATE A SEPERATE THREAD TO HANDLE PUBLISH REQUESTS
    wiced_rtos_create_thread(&MQTTPublishHandle, 10, "MQTTPublishhread", &MQTTPublishThread, 10000, NULL);

    wiced_mqtt_init( mqtt_object_publish );

//GET THE IPV4 ADDRESS AND STORE IT FOR SENDING AS PART OF THE DATA PACKET
    wiced_ip_get_ipv4_address(WICED_STA_INTERFACE, &ipv4address);//store the local ipv4 address in to an array for use by the display
    sprintf(ip_str,      "ip:%d.%d.%d.%d",(ipv4address.ip.v4>>24 & 0xFF), (ipv4address.ip.v4>>16 & 0xFF), (ipv4address.ip.v4>>8 & 0xFF), (ipv4address.ip.v4 & 0xFF));//store in to local string
    sprintf(name_str,   "%s", devicename);
    do
    {
        MQTT_Open_Function(); //call function to open and tell device which topic to publish to

        mqtt_subscribe_function(); //call function to subscribe to a defined topic


        /* configure push button to publish a message- CHANGE THIS COMMNAD FOR DIFFERENT BOARDS BASED ON THE BUTTON GPIIO*/

        //wiced_gpio_input_irq_enable( WICED_GPIO_19, IRQ_TRIGGER_RISING_EDGE, publish_callback, NULL ); //4343W AVN BOARD

        wiced_gpio_input_irq_enable( WICED_GPIO_55, IRQ_TRIGGER_RISING_EDGE, publish_callback, NULL );//NEBULA BOARD

       //wiced_gpio_input_irq_enable( WICED_GPIO_3, IRQ_TRIGGER_RISING_EDGE, publish_callback, NULL );//43907AEVAL1f WITH SHIELD or 43364 board

        while ( 1 )
        {

            wiced_rtos_delay_milliseconds( 100 ); //delay here to allow other threads to run
        }

        //we should never get here

        pub_in_progress = 0; // Reset flag if we got a failure so that another button push is needed after a failure

        WPRINT_APP_INFO(("[MQTT] Closing connection..."));
        mqtt_conn_close( mqtt_object_publish ); //close the coonection


        wiced_rtos_delay_milliseconds( MQTT_DELAY_IN_MILLISECONDS * 2 );
    } while ( 1 );

    wiced_rtos_deinit_semaphore( &publish_msg_semaphore );//deinitialise the semaphore and the objects and free them
    WPRINT_APP_INFO(("[MQTT] Deinit connection...\n"));
    wiced_mqtt_deinit( mqtt_object_publish );
    free( mqtt_object_publish );
    mqtt_object_publish = NULL;

    return;
}
